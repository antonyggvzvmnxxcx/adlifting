---
layout: index.hbs
labels:
  current-version: Versió actual
  download: Descarregar
  download-for: Descarregar per
  other-downloads: Altres Descàrregues
  current: Actual
  lts: LTS
  tagline-current: Últimes característiques
  tagline-lts: Recomanat per a la majoria
  changelog: Canvis
  api: Documentació de l'API
  version-schedule-prompt: O revisi la
  version-schedule-prompt-link-text: Agenda de LTS
---

Node.js® és un entorn d'execució per a JavaScript construït amb el [motor de JavaScript V8 de Chrome](https://v8.dev/).
