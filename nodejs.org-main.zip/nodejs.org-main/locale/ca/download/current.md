---
layout: download-current.hbs
title: Descàrrega
download: Descàrrega
downloads:
    headline: Descàrregues
    lts: LTS
    current: Actual
    tagline-current: Últimes característiques
    tagline-lts: Recomanat per a la majoria
    display-hint: Mostrar descàrregues per a
    intro: >
        Descarregui el codi font de Node.js o un instal·lador pre-compilat per a la seva plataforma, i comenci a desenvolupar avui.
    currentVersion: Versió actual
    buildInstructions: Building Node.js from source on supported platforms
    WindowsInstaller: Windows Installer
    WindowsBinary: Windows Binary
    MacOSInstaller: macOS Installer
    MacOSBinary: macOS Binary
    LinuxBinaries: Linux Binaries
    SourceCode: Source Code
additional:
    headline: Plataformes addicionals
    intro: >
        Membres de la comunitat de Node.js proveeixen paquets pre-compilats de forma no oficial per a plataformes addicionals no suportades per l'equip central de Node.js que poden no estar al mateix nivell de les versions actuals oficials de Node.js.
    platform: Plataforma
    provider: Proveïdor
    SmartOSBinaries: SmartOS Binaries
    DockerImage: Docker Image
    officialDockerImage: Official Node.js Docker Image
    LinuxPowerSystems: Linux on Power LE Systems
    LinuxSystemZ: Linux on System z
    AIXPowerSystems: AIX on Power Systems
---
