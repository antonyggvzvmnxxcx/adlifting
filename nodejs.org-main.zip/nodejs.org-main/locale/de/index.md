---
layout: index.hbs
labels:
  current-version: Aktuelle Version
  download: Download
  download-for: Herunterladen für
  other-downloads: Andere Downloads
  current: Aktuell
  lts: LTS
  tagline-current: Neueste Funktionalitäten
  tagline-lts: Für die meisten Nutzer empfohlen
  changelog: Änderungshistorie
  api: API Doku
  version-schedule-prompt: Oder wirf einen Blick auf den
  version-schedule-prompt-link-text: LTS Release Plan
---

Node.js® ist eine JavaScript-Laufzeitumgebung, die auf [Chromes V8 JavaScript-Engine](https://v8.dev/) basiert.
