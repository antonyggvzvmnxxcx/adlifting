---
title: برمج + تعلم
layout: contribute.hbs
---

# برمج + تعلم

تسمح لك فعاليات برمج + تعلم في البدء (أو التعمق) بمساهمتك في الـ Node.js. سيساعدك المتعاونون ذوو الخبرة اجل القيام اول (أو ثاني، أو ثالث او رابع) مساهمة في الـ Node.js. هم أيضاً سيكونون متوفرين لإجراء دروس تعريفية من تلقاء أنفسهم لأجزاء محددة من الشفرة المصدرية الأساسية للـ Node.js.

* [موسكو ، روسيا في 6 نوفمبر 2019](https://medium.com/piterjs/announcement-node-js-code-learn-in-moscow-fd997241c77)
* شنغهاي ، الصين في [COSCon](https://bagevent.com/event/5744455) : 3 نوفمبر 2019
* ميدلين ، كولومبيا في 21 و 22 جوان [NodeConfCo](https://colombia.nodeconf.com/)
* [سانت بطرسبرغ ، روسيا في 26 ماي](https://medium.com/piterjs/code-learn-ce20d330530f)
* بنغالور، الهند في [Node.js - ملتقى برمج و تعلم](https://www.meetup.com/Polyglot-Languages-Runtimes-Java-JVM-nodejs-Swift/events/256057028/): 17 نوفمبر 2018
* كيلكيني، أيرلندا في [<span dir="rtl">NodeConfEU</span>](https://www.nodeconf.eu/) : 4 نوفمبر 2018
* فانكوفر، كولومبيا البريطانية في [<span dir="rtl">Node Interactive</span>](https://events.linuxfoundation.org/events/node-js-interactive-2018/): 12 أكتوبر 2018
* [أوكلاند في 22 أفريل 2017](https://medium.com/the-node-js-collection/code-learn-learn-how-to-contribute-to-node-js-core-8a2dbdf9be45)
* شنغهاي في JSConf.CN : جويلية 2017
* فانكوفر، كولومبيا البريطانية في [<span dir="rtl">Node Interactive</span>](http://events.linuxfoundation.org/events/node-interactive): 6 أكتوبر 2017
* كيلكيني، أيرلندا في [<span dir="rtl">NodeConfEU</span>](https://www.nodeconf.eu/): 5 نوفمبر 2017
* أوستين في ديسمبر 2016
* طوكيو في نوفمبر 2016
* أمستردام في سبتمبر 2016
* دبلن ولندن في سبتمبر 2015
