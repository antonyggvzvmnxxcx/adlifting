---
layout: index.hbs
labels:
  current-version: الإصدار الحالي
  download: تحميل
  download-for: تحميل النسخة الخاصة بـ
  other-downloads: تحميل نسخ أخرى
  current: النسخة الحالية
  lts: LTS
  tagline-current: آخر المستجدات
  tagline-lts: موصى به لجميع المستخدمين
  changelog: سجل التغييرات
  api: API Docs
  version-schedule-prompt: أو انظر إلى
  version-schedule-prompt-link-text: أجندة LTS
---

Node.js® هو إطار عمل مبني على محرك [Chrome V8](https://v8.dev/).
