---
layout: download.hbs
title: التنزيلات
download: تنزيل
downloads:
    headline: التنزيلات
    lts: مستقر
    current: الحالي
    tagline-current: يحتوي على آخر الميزات
    tagline-lts: موصى به لأغلب المستخدمين
    display-hint: عرض التنزيلات لـ
    intro: >
        قم بتنزيل الكود المصدري للنود جي اس أو مثبت مبني لمنصتك و ابدأ التطوير اليوم.
    currentVersion: آخر نسخة مستقرة
    buildInstructions: بناء Node.js من المصدر على منصات مدعومة
    WindowsInstaller: مثبت للويندوز
    WindowsBinary: ملف ثنائي للويندوز
    MacOSInstaller: مثبت للماك
    MacOSBinary: ملف ثنائي للماك
    LinuxBinaries: ملف ثنائي للينكس
    SourceCode: الكود المصدري
additional:
    headline: منصات إضافية
    intro: >
    platform: منصة
    provider: مزود
    SmartOSBinaries: ملف ثنائي لـSmartOS
    DockerImage: اسطوانة دوكر
    officialDockerImage: اسطوانة نود جي اس الرسمية الخاصة بالدوكر
    LinuxPowerSystems: لينكس على Power LE Systems
    LinuxSystemZ: لينكس على System z
    AIXPowerSystems: AIX على Power Systems
---
