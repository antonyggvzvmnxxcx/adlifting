---
name: 🐛 Bug Report
about: If something isn't working as expected 🤔.
---

<!--
Thanks for wanting to report an issue you've found on the nodejs.org website.

Please fill in the template below. If unsure about something, just do as best
as you're able. If you are reporting a visual glitch, it will be much easier
for us to fix it when you attach a screenshot as well.
-->

- **URL**:
- **Browser version**:
- **Operating system**:

<!-- Enter your issue details below this comment. -->
