---
name: 🚀 Feature Request
about: I have a suggestion (and may want to implement it 🙂)!
---

<!--
You have an idea how to improve the site? That's awesome!

Before submitting, please have a look at the existing issues if there's already
something related to your suggestion.

We are also working on a relaunch at the moment, so it might be a good idea to
check out our plans there as well: https://github.com/nodejs/nodejs.dev/issues/

Help is always welcome!
-->
