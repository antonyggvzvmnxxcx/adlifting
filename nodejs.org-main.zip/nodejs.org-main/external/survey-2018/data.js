var tab7content = [{
  'name': 'Other',
  'value': 2,
  'unit': '%'
}, {
  'name': 'Grad degree',
  'value': 21,
  'unit': '%'
}, {
  'name': 'College degree',
  'value': 51,
  'unit': '%'
}, {
  'name': 'Some college',
  'value': 10,
  'unit': '%'
}, {
  'name': 'High school or less',
  'value': 16,
  'unit': '%'
}]

var tab10_1_1content = [{
  'name': 'Prof’l dev experience (median yrs)',
  'value': 7.5,
  'unit': ''
}, {
  'name': 'Co size (median # ee’s)',
  'value': 99,
  'unit': ''
}, {
  'name': '',
  'value': '------------------------------------------------------------------------------------------------------------------------------------------',
  'unit': ''
}, {
  'name': 'Managers',
  'value': 29,
  'unit': '%'
}, {
  'name': 'Developers',
  'value': 60,
  'unit': '%'
}, {
  'name': 'Prof’l dev experience (10+ yrs)',
  'value': 42,
  'unit': '%'
}]

var tab10_1_2content = [{
  'name': 'Prof’l dev experience (median yrs)',
  'value': 5.3,
  'unit': ''
}, {
  'name': 'Co size (median # ee’s)',
  'value': 24,
  'unit': ''
}, {
  'name': '',
  'value': '------------------------------------------------------------------------------------------------------------------------------------------',
  'unit': ''
}, {
  'name': 'Managers',
  'value': 23,
  'unit': '%'
}, {
  'name': 'Developers',
  'value': 67,
  'unit': '%'
}, {
  'name': 'Prof’l dev experience (10+ yrs)',
  'value': 29,
  'unit': '%'
}]

var tab10_1_2contenttp = [{
  'name': 'Managers',
  'value': 0
}]

var tab10_1_3content = [{
  'name': 'Prof’l dev experience (median yrs)',
  'value': 3.7,
  'unit': ''
}, {
  'name': 'Co size (median # ee’s)',
  'value': 24,
  'unit': ''
}, {
  'name': '',
  'value': '------------------------------------------------------------------------------------------------------------------------------------------',
  'unit': ''
}, {
  'name': 'Managers',
  'value': 24,
  'unit': '%'
}, {
  'name': 'Developers',
  'value': 64,
  'unit': '%'
}, {
  'name': 'Prof’l dev experience (10+ yrs)',
  'value': 18,
  'unit': '%'
}]

var tab10_1_3contenttp = [{
  'name': 'Developers',
  'value': 0
}]

var tab10_1_4content = [{
  'name': 'Prof’l dev experience (median yrs)',
  'value': 4.4,
  'unit': ''
}, {
  'name': 'Co size (median # ee’s)',
  'value': 40,
  'unit': ''
}, {
  'name': '',
  'value': '------------------------------------------------------------------------------------------------------------------------------------------',
  'unit': ''
}, {
  'name': 'Managers',
  'value': 24,
  'unit': '%'
}, {
  'name': 'Developers',
  'value': 70,
  'unit': '%'
}, {
  'name': 'Prof’l dev experience (10+ yrs)',
  'value': 28,
  'unit': '%'
}]

var tab10_2_1content = [{
  'name': 'Age (median)',
  'value': 33,
  'unit': ''
}, {
  'name': '',
  'value': '------------------------------------------------------------------------------------------------------------------------------------------',
  'unit': ''
}, {
  'name': 'Have grad degree',
  'value': 15,
  'unit': '%'
}, {
  'name': 'Male',
  'value': 91,
  'unit': '%'
}, {
  'name': 'Age (% 35+)',
  'value': 41,
  'unit': '%'
}, {
  'name': 'English primary language',
  'value': 92,
  'unit': '%'
}]

var tab10_2_2content = [{
  'name': 'Age (median)',
  'value': 31,
  'unit': ''
}, {
  'name': '',
  'value': '------------------------------------------------------------------------------------------------------------------------------------------',
  'unit': ''
}, {
  'name': 'Have grad degree',
  'value': 28,
  'unit': '%'
}, {
  'name': 'Male',
  'value': 95,
  'unit': '%'
}, {
  'name': 'Age (% 35+)',
  'value': 31,
  'unit': '%'
}, {
  'name': 'English primary language',
  'value': 21,
  'unit': '%'
}]

var tab10_2_3content = [{
  'name': 'Age (median)',
  'value': 29,
  'unit': ''
}, {
  'name': '',
  'value': '------------------------------------------------------------------------------------------------------------------------------------------',
  'unit': ''
}, {
  'name': 'Have grad degree',
  'value': 20,
  'unit': '%'
}, {
  'name': 'Male',
  'value': 97,
  'unit': '%'
}, {
  'name': 'Age (% 35+)',
  'value': 20,
  'unit': '%'
}, {
  'name': 'English primary language',
  'value': 42,
  'unit': '%'
}]

var tab10_2_3contenttp = [{
  'name': 'Age (% 35+)',
  'value': 1
}, {
  'name': 'Age (median)',
  'value': 1
}, {
  'name': 'English primary language',
  'value': 1
}]

var tab10_2_4content = [{
  'name': 'Age (median)',
  'value': 30,
  'unit': ''
}, {
  'name': '',
  'value': '------------------------------------------------------------------------------------------------------------------------------------------',
  'unit': ''
}, {
  'name': 'Have grad degree',
  'value': 8,
  'unit': '%'
}, {
  'name': 'Male',
  'value': 96,
  'unit': '%'
}, {
  'name': 'Age (% 35+)',
  'value': 24,
  'unit': '%'
}, {
  'name': 'English primary language',
  'value': 1,
  'unit': '%'
}]

var tab13_1content = [{
  'name': 'Security',
  'value': '<1',
  'unit': '%'
}, {
  'name': 'IoT',
  'value': 1,
  'unit': '%'
}, {
  'name': 'Mobile',
  'value': 2,
  'unit': '%'
}, {
  'name': 'Desktop Apps',
  'value': 2,
  'unit': '%'
}, {
  'name': 'Ops/DevOps',
  'value': 3,
  'unit': '%'
}, {
  'name': 'Front-end',
  'value': 15,
  'unit': '%'
}, {
  'name': 'Full Stack',
  'value': 42,
  'unit': '%'
}, {
  'name': 'Back-end',
  'value': 32,
  'unit': '%'
}]

var tab13_1contenttp = [{
  'name': 'Back-end',
  'value': 0
}]

var tab13_2content = [{
  'name': 'Security',
  'value': '1',
  'unit': '%'
}, {
  'name': 'IoT',
  'value': 2,
  'unit': '%'
}, {
  'name': 'Mobile',
  'value': 2,
  'unit': '%'
}, {
  'name': 'Desktop Apps',
  'value': 2,
  'unit': '%'
}, {
  'name': 'Ops/DevOps',
  'value': 1,
  'unit': '%'
}, {
  'name': 'Front-end',
  'value': 14,
  'unit': '%'
}, {
  'name': 'Full Stack',
  'value': 39,
  'unit': '%'
}, {
  'name': 'Back-end',
  'value': 38,
  'unit': '%'
}]

var tab13_3content = [{
  'name': 'Security',
  'value': '<1',
  'unit': '%'
}, {
  'name': 'IoT',
  'value': 1,
  'unit': '%'
}, {
  'name': 'Mobile',
  'value': 2,
  'unit': '%'
}, {
  'name': 'Desktop Apps',
  'value': 2,
  'unit': '%'
}, {
  'name': 'Ops/DevOps',
  'value': '<1',
  'unit': '%'
}, {
  'name': 'Front-end',
  'value': 13,
  'unit': '%'
}, {
  'name': 'Full Stack',
  'value': 38,
  'unit': '%'
}, {
  'name': 'Back-end',
  'value': 43,
  'unit': '%'
}]

var tab13_3contenttp = [{
  'name': 'Front-end',
  'value': 0
}, {
  'name': 'Back-end',
  'value': 1
}]

var tab13_4content = [{
  'name': 'Security',
  'value': 0,
  'unit': '%'
}, {
  'name': 'IoT',
  'value': 2,
  'unit': '%'
}, {
  'name': 'Mobile',
  'value': 2,
  'unit': '%'
}, {
  'name': 'Desktop Apps',
  'value': 1,
  'unit': '%'
}, {
  'name': 'Ops/DevOps',
  'value': 1,
  'unit': '%'
}, {
  'name': 'Front-end',
  'value': 11,
  'unit': '%'
}, {
  'name': 'Full Stack',
  'value': 41,
  'unit': '%'
}, {
  'name': 'Back-end',
  'value': 42,
  'unit': '%'
}]

var tab14_1_1content = [{
  'name': 'Years using Node.js (median)',
  'value': 2.2,
  'unit': ''
}, {
  'name': 'Prof’l dev experience (10+ yrs)',
  'value': 31,
  'unit': ''
}, {
  'name': 'Prof’l dev experience (median yrs)',
  'value': 4.7,
  'unit': ''
}, {
  'name': 'Co size (median # ee’s)',
  'value': 54,
  'unit': ''
}, {
  'name': '',
  'value': '------------------------------------------------------------------------------------------------------------------------------------------',
  'unit': ''
}, {
  'name': '% Prof Dev time Use Node.js (median)',
  'value': 61,
  'unit': '%'
}, {
  'name': 'Managers',
  'value': 25,
  'unit': '%'
}, {
  'name': 'Developers',
  'value': 69,
  'unit': '%'
}]

var tab14_1_1contenttp = [{
  'name': '% Prof Dev time Use Node.js (median)',
  'value': 1
}, {
  'name': 'Managers',
  'value': 0
}, {
  'name': 'Prof’l dev experience (median yrs)',
  'value': 0
}]

var tab14_1_2content = [{
  'name': 'Years using Node.js (median)',
  'value': 2.5,
  'unit': ''
}, {
  'name': 'Prof’l dev experience (10+ yrs)',
  'value': 32,
  'unit': ''
}, {
  'name': 'Prof’l dev experience (median yrs)',
  'value': 6.0,
  'unit': ''
}, {
  'name': 'Co size (median # ee’s)',
  'value': 37,
  'unit': ''
}, {
  'name': '',
  'value': '------------------------------------------------------------------------------------------------------------------------------------------',
  'unit': ''
}, {
  'name': '% Prof Dev time Use Node.js (median)',
  'value': 62,
  'unit': '%'
}, {
  'name': 'Managers',
  'value': 28,
  'unit': '%'
}, {
  'name': 'Developers',
  'value': 61,
  'unit': '%'
}]

var tab14_1_3content = [{
  'name': 'Years using Node.js (median)',
  'value': 2.3,
  'unit': ''
}, {
  'name': 'Prof’l dev experience (10+ yrs)',
  'value': 29,
  'unit': ''
}, {
  'name': 'Prof’l dev experience (median yrs)',
  'value': 5.6,
  'unit': ''
}, {
  'name': 'Co size (median # ee’s)',
  'value': 79,
  'unit': ''
}, {
  'name': '',
  'value': '------------------------------------------------------------------------------------------------------------------------------------------',
  'unit': ''
}, {
  'name': '% Prof Dev time Use Node.js (median)',
  'value': 27,
  'unit': '%'
}, {
  'name': 'Managers',
  'value': 19,
  'unit': '%'
}, {
  'name': 'Developers',
  'value': 71,
  'unit': '%'
}]

var tab14_1_4content = [{
  'name': 'Years using Node.js (median)',
  'value': 2.2,
  'unit': ''
}, {
  'name': 'Prof’l dev experience (10+ yrs)',
  'value': 38,
  'unit': ''
}, {
  'name': 'Prof’l dev experience (median yrs)',
  'value': 6.1,
  'unit': ''
}, {
  'name': 'Co size (median # ee’s)',
  'value': 44,
  'unit': ''
}, {
  'name': '',
  'value': '------------------------------------------------------------------------------------------------------------------------------------------',
  'unit': ''
}, {
  'name': '% Prof Dev time Use Node.js (median)',
  'value': 39,
  'unit': '%'
}, {
  'name': 'Managers',
  'value': 32,
  'unit': '%'
}, {
  'name': 'Developers',
  'value': 50,
  'unit': '%'
} ]

var tab14_1_4contenttp = [{
  'name': 'Developers',
  'value': 0
}]

var tab14_2_1content = [{
  'name': 'Age (median)',
  'value': 31,
  'unit': ''
}, {
  'name': '',
  'value': '------------------------------------------------------------------------------------------------------------------------------------------',
  'unit': ''
}, {
  'name': 'Latin America',
  'value': 8,
  'unit': '%'
}, {
  'name': 'APAC',
  'value': 19,
  'unit': '%'
}, {
  'name': 'EMEA',
  'value': 46,
  'unit': '%'
}, {
  'name': 'US/CA',
  'value': 27,
  'unit': '%'
}, {
  'name': 'Have grad degree',
  'value': 22,
  'unit': '%'
}, {
  'name': 'Male',
  'value': 94,
  'unit': '%'
}, {
  'name': 'English primary language',
  'value': 43,
  'unit': '%'
}]

var tab14_2_1contenttp = [{
  'name': 'US/CA',
  'value': 0
}]

var tab14_2_2content = [{
  'name': 'Age (median)',
  'value': 31,
  'unit': ''
}, {
  'name': '',
  'value': '------------------------------------------------------------------------------------------------------------------------------------------',
  'unit': ''
}, {
  'name': 'Latin America',
  'value': 8,
  'unit': '%'
}, {
  'name': 'APAC',
  'value': 16,
  'unit': '%'
}, {
  'name': 'EMEA',
  'value': 43,
  'unit': '%'
}, {
  'name': 'US/CA',
  'value': 34,
  'unit': '%'
}, {
  'name': 'Have grad degree',
  'value': 19,
  'unit': '%'
}, {
  'name': 'Male',
  'value': 95,
  'unit': '%'
}, {
  'name': 'English primary language',
  'value': 48,
  'unit': '%'
}]

var tab14_2_3content = [{
  'name': 'Age (median)',
  'value': 31,
  'unit': ''
}, {
  'name': '',
  'value': '------------------------------------------------------------------------------------------------------------------------------------------',
  'unit': ''
}, {
  'name': 'Latin America',
  'value': 6,
  'unit': '%'
}, {
  'name': 'APAC',
  'value': 15,
  'unit': '%'
}, {
  'name': 'EMEA',
  'value': 45,
  'unit': '%'
}, {
  'name': 'US/CA',
  'value': 35,
  'unit': '%'
}, {
  'name': 'Have grad degree',
  'value': 18,
  'unit': '%'
}, {
  'name': 'Male',
  'value': 95,
  'unit': '%'
}, {
  'name': 'English primary language',
  'value': 44,
  'unit': '%'
}]

var tab14_2_4content = [{
  'name': 'Age (median)',
  'value': 35,
  'unit': ''
}, {
  'name': '',
  'value': '------------------------------------------------------------------------------------------------------------------------------------------',
  'unit': ''
}, {
  'name': 'Latin America',
  'value': 4,
  'unit': '%'
}, {
  'name': 'APAC',
  'value': 10,
  'unit': '%'
}, {
  'name': 'EMEA',
  'value': 45,
  'unit': '%'
}, {
  'name': 'US/CA',
  'value': 39,
  'unit': '%'
}, {
  'name': 'Have grad degree',
  'value': 29,
  'unit': '%'
}, {
  'name': 'Male',
  'value': 91,
  'unit': '%'
}, {
  'name': 'English primary language',
  'value': 48,
  'unit': '%'
}]

var tab14_2_4contenttp = [{
  'name': 'Age (median)',
  'value': 1
}]

var tab16_1_1content = [{
  'name': 'Depl not req’d',
  'value': 5,
  'unit': '%'
}, {
  'name': 'Red Hat Openshift',
  'value': 1,
  'unit': '%'
}, {
  'name': 'IBM Bluemix',
  'value': 2,
  'unit': '%'
}, {
  'name': 'Microsoft Azure',
  'value': 5,
  'unit': '%'
}, {
  'name': 'Google Cloud',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Digital Ocean',
  'value': 7,
  'unit': '%'
}, {
  'name': 'Heroku',
  'value': 11,
  'unit': '%'
}, {
  'name': 'On-Premise Infrastructure',
  'value': 20,
  'unit': '%'
}, {
  'name': 'Amazon Web Services',
  'value': 37,
  'unit': '%'
}]

var tab16_1_2content = [{
  'name': 'Depl not req’d',
  'value': 7,
  'unit': '%'
}, {
  'name': 'Red Hat Openshift',
  'value': 1,
  'unit': '%'
}, {
  'name': 'IBM Bluemix',
  'value': 1,
  'unit': '%'
}, {
  'name': 'Microsoft Azure',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Google Cloud',
  'value': 5,
  'unit': '%'
}, {
  'name': 'Digital Ocean',
  'value': 9,
  'unit': '%'
}, {
  'name': 'Heroku',
  'value': 11,
  'unit': '%'
}, {
  'name': 'On-Premise Infrastructure',
  'value': 27,
  'unit': '%'
}, {
  'name': 'Amazon Web Services',
  'value': 23,
  'unit': '%'
}]

var tab16_1_3content = [{
  'name': 'Depl not req’d',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Red Hat Openshift',
  'value': 2,
  'unit': '%'
}, {
  'name': 'IBM Bluemix',
  'value': 1,
  'unit': '%'
}, {
  'name': 'Microsoft Azure',
  'value': 7,
  'unit': '%'
}, {
  'name': 'Google Cloud',
  'value': 5,
  'unit': '%'
}, {
  'name': 'Digital Ocean',
  'value': 7,
  'unit': '%'
}, {
  'name': 'Heroku',
  'value': 12,
  'unit': '%'
}, {
  'name': 'On-Premise Infrastructure',
  'value': 11,
  'unit': '%'
}, {
  'name': 'Amazon Web Services',
  'value': 42,
  'unit': '%'
}]

var tab16_1_3contenttp = [{
  'name': 'Depl not req’d',
  'value': 0
}, {
  'name': 'Microsoft Azure',
  'value': 1
}, {
  'name': 'Heroku',
  'value': 1
}, {
  'name': 'On-Premise Infrastructure',
  'value': 0
}, {
  'name': 'Amazon Web Services',
  'value': 1
}]

var tab16_1_4content = [{
  'name': 'Depl not req’d',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Red Hat Openshift',
  'value': 1,
  'unit': '%'
}, {
  'name': 'IBM Bluemix',
  'value': 3,
  'unit': '%'
}, {
  'name': 'Microsoft Azure',
  'value': 5,
  'unit': '%'
}, {
  'name': 'Google Cloud',
  'value': 6,
  'unit': '%'
}, {
  'name': 'Digital Ocean',
  'value': 7,
  'unit': '%'
}, {
  'name': 'Heroku',
  'value': 16,
  'unit': '%'
}, {
  'name': 'On-Premise Infrastructure',
  'value': 12,
  'unit': '%'
}, {
  'name': 'Amazon Web Services',
  'value': 40,
  'unit': '%'
}]

var tab16_1_4contenttp = [{
  'name': 'Heroku',
  'value': 1
}]

var tab16_2_1content = [{
  'name': 'Depl not req’d',
  'value': 16,
  'unit': '%'
}, {
  'name': 'Red Hat Openshift',
  'value': 1,
  'unit': '%'
}, {
  'name': 'IBM Bluemix',
  'value': 1,
  'unit': '%'
}, {
  'name': 'Microsoft Azure',
  'value': 3,
  'unit': '%'
}, {
  'name': 'Google Cloud',
  'value': 3,
  'unit': '%'
}, {
  'name': 'Digital Ocean',
  'value': 5,
  'unit': '%'
}, {
  'name': 'Heroku',
  'value': 9,
  'unit': '%'
}, {
  'name': 'Amazon Web Services',
  'value': 24,
  'unit': '%'
}, {
  'name': 'On-Premise Infrastructure',
  'value': 32,
  'unit': '%'
}]

var tab16_2_1contenttp = [{
  'name': 'IBM Bluemix',
  'value': 0
}]

var tab16_2_2content = [{
  'name': 'Depl not req’d',
  'value': 16,
  'unit': '%'
}, {
  'name': 'Red Hat Openshift',
  'value': 1,
  'unit': '%'
}, {
  'name': 'IBM Bluemix',
  'value': 1,
  'unit': '%'
}, {
  'name': 'Microsoft Azure',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Google Cloud',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Digital Ocean',
  'value': 6,
  'unit': '%'
}, {
  'name': 'Heroku',
  'value': 12,
  'unit': '%'
}, {
  'name': 'Amazon Web Services',
  'value': 17,
  'unit': '%'
}, {
  'name': 'On-Premise Infrastructure',
  'value': 32,
  'unit': '%'
}]

var tab16_2_2contenttp = [{
  'name': 'Depl not req’d',
  'value': 0
}, {
  'name': 'Microsoft Azure',
  'value': 1
}, {
  'name': 'Google Cloud',
  'value': 1
}]

var tab16_2_3content = [{
  'name': 'Depl not req’d',
  'value': 14,
  'unit': '%'
}, {
  'name': 'Red Hat Openshift',
  'value': 1,
  'unit': '%'
}, {
  'name': 'IBM Bluemix',
  'value': 1,
  'unit': '%'
}, {
  'name': 'Microsoft Azure',
  'value': 7,
  'unit': '%'
}, {
  'name': 'Google Cloud',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Digital Ocean',
  'value': 7,
  'unit': '%'
}, {
  'name': 'Heroku',
  'value': 16,
  'unit': '%'
}, {
  'name': 'Amazon Web Services',
  'value': 27,
  'unit': '%'
}, {
  'name': 'On-Premise Infrastructure',
  'value': 20,
  'unit': '%'
}]

var tab16_2_3contenttp = [{
  'name': 'Depl not req’d',
  'value': 0
}, {
  'name': 'Microsoft Azure',
  'value': 1
}, {
  'name': 'Heroku',
  'value': 1
}, {
  'name': 'Amazon Web Services',
  'value': 1
}]

var tab16_2_4content = [{
  'name': 'Depl not req’d',
  'value': 13,
  'unit': '%'
}, {
  'name': 'Red Hat Openshift',
  'value': 1,
  'unit': '%'
}, {
  'name': 'IBM Bluemix',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Microsoft Azure',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Google Cloud',
  'value': 1,
  'unit': '%'
}, {
  'name': 'Digital Ocean',
  'value': 5,
  'unit': '%'
}, {
  'name': 'Heroku',
  'value': 20,
  'unit': '%'
}, {
  'name': 'Amazon Web Services',
  'value': 20,
  'unit': '%'
}, {
  'name': 'On-Premise Infrastructure',
  'value': 22,
  'unit': '%'
}]

var tab16_2_4contenttp = [{
  'name': 'Heroku',
  'value': 1
}]

var tab17_1_1content = [{
  'name': 'Depl not req’d',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Red Hat Openshift',
  'value': 1,
  'unit': '%'
}, {
  'name': 'IBM Bluemix',
  'value': 2,
  'unit': '%'
}, {
  'name': 'Microsoft Azure',
  'value': 5,
  'unit': '%'
}, {
  'name': 'Google Cloud',
  'value': 5,
  'unit': '%'
}, {
  'name': 'Digital Ocean',
  'value': 5,
  'unit': '%'
}, {
  'name': 'Heroku',
  'value': 10,
  'unit': '%'
}, {
  'name': 'On-Premise Infrastructure',
  'value': 23,
  'unit': '%'
}, {
  'name': 'Amazon Web Services',
  'value': 36,
  'unit': '%'
}]

var tab17_1_2content = [{
  'name': 'Depl not req’d',
  'value': 3,
  'unit': '%'
}, {
  'name': 'Red Hat Openshift',
  'value': 1,
  'unit': '%'
}, {
  'name': 'IBM Bluemix',
  'value': 1,
  'unit': '%'
}, {
  'name': 'Microsoft Azure',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Google Cloud',
  'value': 5,
  'unit': '%'
}, {
  'name': 'Digital Ocean',
  'value': 11,
  'unit': '%'
}, {
  'name': 'Heroku',
  'value': 14,
  'unit': '%'
}, {
  'name': 'On-Premise Infrastructure',
  'value': 20,
  'unit': '%'
}, {
  'name': 'Amazon Web Services',
  'value': 33,
  'unit': '%'
}]

var tab17_1_3content = [{
  'name': 'Depl not req’d',
  'value': 13,
  'unit': '%'
}, {
  'name': 'Red Hat Openshift',
  'value': 1,
  'unit': '%'
}, {
  'name': 'IBM Bluemix',
  'value': 0,
  'unit': '%'
}, {
  'name': 'Microsoft Azure',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Google Cloud',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Digital Ocean',
  'value': 8,
  'unit': '%'
}, {
  'name': 'Heroku',
  'value': 9,
  'unit': '%'
}, {
  'name': 'On-Premise Infrastructure',
  'value': 24,
  'unit': '%'
}, {
  'name': 'Amazon Web Services',
  'value': 29,
  'unit': '%'
}]

var tab17_1_4content = [{
  'name': 'Depl not req’d',
  'value': 13,
  'unit': '%'
}, {
  'name': 'Red Hat Openshift',
  'value': 2,
  'unit': '%'
}, {
  'name': 'IBM Bluemix',
  'value': 3,
  'unit': '%'
}, {
  'name': 'Microsoft Azure',
  'value': 9,
  'unit': '%'
}, {
  'name': 'Google Cloud',
  'value': 5,
  'unit': '%'
}, {
  'name': 'Digital Ocean',
  'value': 5,
  'unit': '%'
}, {
  'name': 'Heroku',
  'value': 8,
  'unit': '%'
}, {
  'name': 'On-Premise Infrastructure',
  'value': 20,
  'unit': '%'
}, {
  'name': 'Amazon Web Services',
  'value': 16,
  'unit': '%'
}]

var tab17_1_4contenttp = [{
  'name': 'Microsoft Azure',
  'value': 1
}]

var tab17_2_1content = [{
  'name': 'Depl not req’d',
  'value': 15,
  'unit': '%'
}, {
  'name': 'Red Hat Openshift',
  'value': 1,
  'unit': '%'
}, {
  'name': 'IBM Bluemix',
  'value': 1,
  'unit': '%'
}, {
  'name': 'Microsoft Azure',
  'value': 5,
  'unit': '%'
}, {
  'name': 'Google Cloud',
  'value': 3,
  'unit': '%'
}, {
  'name': 'Digital Ocean',
  'value': 3,
  'unit': '%'
}, {
  'name': 'Heroku',
  'value': 12,
  'unit': '%'
}, {
  'name': 'Amazon Web Services',
  'value': 24,
  'unit': '%'
}, {
  'name': 'On-Premise Infrastructure',
  'value': 29,
  'unit': '%'
}]

var tab17_2_1contenttp = [{
  'name': 'Microsoft Azure',
  'value': 1
}]

var tab17_2_2content = [{
  'name': 'Depl not req’d',
  'value': 12,
  'unit': '%'
}, {
  'name': 'Red Hat Openshift',
  'value': 1,
  'unit': '%'
}, {
  'name': 'IBM Bluemix',
  'value': 1,
  'unit': '%'
}, {
  'name': 'Microsoft Azure',
  'value': 3,
  'unit': '%'
}, {
  'name': 'Google Cloud',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Digital Ocean',
  'value': 8,
  'unit': '%'
}, {
  'name': 'Heroku',
  'value': 14,
  'unit': '%'
}, {
  'name': 'Amazon Web Services',
  'value': 22,
  'unit': '%'
}, {
  'name': 'On-Premise Infrastructure',
  'value': 29,
  'unit': '%'
}]

var tab17_2_2contenttp = [{
  'name': 'Depl not req’d',
  'value': 0
}, {
  'name': 'Heroku',
  'value': 1
}]

var tab17_2_3content = [{
  'name': 'Depl not req’d',
  'value': 20,
  'unit': '%'
}, {
  'name': 'Red Hat Openshift',
  'value': 1,
  'unit': '%'
}, {
  'name': 'IBM Bluemix',
  'value': 1,
  'unit': '%'
}, {
  'name': 'Microsoft Azure',
  'value': 2,
  'unit': '%'
}, {
  'name': 'Google Cloud',
  'value': 2,
  'unit': '%'
}, {
  'name': 'Digital Ocean',
  'value': 7,
  'unit': '%'
}, {
  'name': 'Heroku',
  'value': 9,
  'unit': '%'
}, {
  'name': 'Amazon Web Services',
  'value': 17,
  'unit': '%'
}, {
  'name': 'On-Premise Infrastructure',
  'value': 33,
  'unit': '%'
}]

var tab17_2_3contenttp = [{
  'name': 'Depl not req’d',
  'value': 0
}, {
  'name': 'On-Premise Infrastructure',
  'value': 1
}]

var tab17_2_4content = [{
  'name': 'Depl not req’d',
  'value': 27,
  'unit': '%'
}, {
  'name': 'Red Hat Openshift',
  'value': 2,
  'unit': '%'
}, {
  'name': 'IBM Bluemix',
  'value': 2,
  'unit': '%'
}, {
  'name': 'Microsoft Azure',
  'value': 7,
  'unit': '%'
}, {
  'name': 'Google Cloud',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Digital Ocean',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Heroku',
  'value': 7,
  'unit': '%'
}, {
  'name': 'Amazon Web Services',
  'value': 10,
  'unit': '%'
}, {
  'name': 'On-Premise Infrastructure',
  'value': 25,
  'unit': '%'
}]

var tab17_2_4contenttp = [{
  'name': 'Microsoft Azure',
  'value': 1
}]

var tab18_1content = [{
  'name': 'Hobbyist ONLY',
  'value': 2,
  'unit': '%'
}, {
  'name': 'Embedded Systems',
  'value': 8,
  'unit': '%'
}, {
  'name': 'Big Data/Analytics',
  'value': 13,
  'unit': '%'
}, {
  'name': 'Hobbyist',
  'value': 32,
  'unit': '%'
}, {
  'name': 'Enterprise',
  'value': 47,
  'unit': '%'
}, {
  'name': 'Web Apps',
  'value': 82,
  'unit': '%'
}]

var tab18_2content = [{
  'name': 'Hobbyist ONLY',
  'value': 2,
  'unit': '%'
}, {
  'name': 'Embedded Systems',
  'value': 7,
  'unit': '%'
}, {
  'name': 'Big Data/Analytics',
  'value': 14,
  'unit': '%'
}, {
  'name': 'Hobbyist',
  'value': 41,
  'unit': '%'
}, {
  'name': 'Enterprise',
  'value': 43,
  'unit': '%'
}, {
  'name': 'Web Apps',
  'value': 92,
  'unit': '%'
}]

var tab18_3content = [{
  'name': 'Hobbyist ONLY',
  'value': 3,
  'unit': '%'
}, {
  'name': 'Embedded Systems',
  'value': 3,
  'unit': '%'
}, {
  'name': 'Big Data/Analytics',
  'value': 7,
  'unit': '%'
}, {
  'name': 'Hobbyist',
  'value': 35,
  'unit': '%'
}, {
  'name': 'Enterprise',
  'value': 35,
  'unit': '%'
}, {
  'name': 'Web Apps',
  'value': 89,
  'unit': '%'
}]

var tab18_4content = [{
  'name': 'Hobbyist ONLY',
  'value': 10,
  'unit': '%'
}, {
  'name': 'Embedded Systems',
  'value': 19,
  'unit': '%'
}, {
  'name': 'Big Data/Analytics',
  'value': 13,
  'unit': '%'
}, {
  'name': 'Hobbyist',
  'value': 37,
  'unit': '%'
}, {
  'name': 'Enterprise',
  'value': 40,
  'unit': '%'
}, {
  'name': 'Web Apps',
  'value': 66,
  'unit': '%'
}]

var tab19_1content = [{
  'name': 'Messaging',
  'value': 21,
  'unit': '%'
}, {
  'name': 'CI',
  'value': 40,
  'unit': '%'
}, {
  'name': 'Containers/Cloud',
  'value': 62,
  'unit': '%'
}, {
  'name': 'Load Balancing',
  'value': 65,
  'unit': '%'
}, {
  'name': 'Node.js Frameworks',
  'value': 84,
  'unit': '%'
}, {
  'name': 'Front-end Frameworks',
  'value': 83,
  'unit': '%'
}, {
  'name': 'Databases',
  'value': 98,
  'unit': '%'
}]

var tab19_2content = [{
  'name': 'Messaging',
  'value': 15,
  'unit': '%'
}, {
  'name': 'CI',
  'value': 45,
  'unit': '%'
}, {
  'name': 'Containers/Cloud',
  'value': 61,
  'unit': '%'
}, {
  'name': 'Load Balancing',
  'value': 68,
  'unit': '%'
}, {
  'name': 'Node.js Frameworks',
  'value': 90,
  'unit': '%'
}, {
  'name': 'Front-end Frameworks',
  'value': 93,
  'unit': '%'
}, {
  'name': 'Databases',
  'value': 97,
  'unit': '%'
}]

var tab19_2contenttp = [{
  'name': 'Node.js Frameworks',
  'value': 1
}]

var tab19_3content = [{
  'name': 'Messaging',
  'value': 4,
  'unit': '%'
}, {
  'name': 'CI',
  'value': 40,
  'unit': '%'
}, {
  'name': 'Containers/Cloud',
  'value': 48,
  'unit': '%'
}, {
  'name': 'Load Balancing',
  'value': 48,
  'unit': '%'
}, {
  'name': 'Node.js Frameworks',
  'value': 67,
  'unit': '%'
}, {
  'name': 'Front-end Frameworks',
  'value': 94,
  'unit': '%'
}, {
  'name': 'Databases',
  'value': 89,
  'unit': '%'
}]

var tab19_4content = [{
  'name': 'Messaging',
  'value': 12,
  'unit': '%'
}, {
  'name': 'CI',
  'value': 27,
  'unit': '%'
}, {
  'name': 'Containers/Cloud',
  'value': 45,
  'unit': '%'
}, {
  'name': 'Load Balancing',
  'value': 44,
  'unit': '%'
}, {
  'name': 'Node.js Frameworks',
  'value': 59,
  'unit': '%'
}, {
  'name': 'Front-end Frameworks',
  'value': 69,
  'unit': '%'
}, {
  'name': 'Databases',
  'value': 92,
  'unit': '%'
}]

var tab19_4contenttp = [{
  'name': 'CI',
  'value': 0
}]

var tab20_1content = [{
  'name': 'PostgreSQL',
  'value': 34,
  'unit': '%'
}, {
  'name': 'Redis',
  'value': 39,
  'unit': '%'
}, {
  'name': 'MYSQL',
  'value': 40,
  'unit': '%'
}, {
  'name': 'Mongo DB',
  'value': 62,
  'unit': '%'
}, {
  'name': 'JSON File',
  'value': 67,
  'unit': '%'
}]

var tab20_1contenttp = [{
  'name': 'Redis',
  'value': 0
}]

var tab20_2content = [{
  'name': 'Vue',
  'value': 21,
  'unit': '%'
}, {
  'name': 'Angular2',
  'value': 26,
  'unit': '%'
}, {
  'name': 'Angular',
  'value': 26,
  'unit': '%'
}, {
  'name': 'JQuery',
  'value': 41,
  'unit': '%'
}, {
  'name': 'React',
  'value': 53,
  'unit': '%'
}]

var tab20_2contenttp = [{
  'name': 'JQuery',
  'value': 0
}, {
  'name': 'Angular',
  'value': 0
}, {
  'name': 'Angular2',
  'value': 1
}, {
  'name': 'Vue',
  'value': 1
}]

var tab20_3content = [{
  'name': 'Restify',
  'value': 8,
  'unit': '%'
}, {
  'name': 'KOA',
  'value': 11,
  'unit': '%'
}, {
  'name': 'Hapi',
  'value': 13,
  'unit': '%'
}, {
  'name': 'GraphQL',
  'value': 21,
  'unit': '%'
}, {
  'name': 'Express',
  'value': 73,
  'unit': '%'
}]

var tab20_3contenttp = [{
  'name': 'GraphQL',
  'value': 1
}]

var tab20_4content = [{
  'name': 'Apache Traffic Sv',
  'value': 1,
  'unit': '%'
}, {
  'name': 'HA Proxy',
  'value': 8,
  'unit': '%'
}, {
  'name': 'Apache HTTP',
  'value': 15,
  'unit': '%'
}, {
  'name': 'Pm2',
  'value': 34,
  'unit': '%'
}, {
  'name': 'Nginx',
  'value': 48,
  'unit': '%'
}]

var tab20_4contenttp = [{
  'name': 'Nginx',
  'value': 0
}, {
  'name': 'HA Proxy',
  'value': 0
}]

var tab20_5content = [{
  'name': 'Azure Functions',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Google Cloud Functions',
  'value': 9,
  'unit': '%'
}, {
  'name': 'Kuber/netes',
  'value': 12,
  'unit': '%'
}, {
  'name': 'AWS Lambda',
  'value': 20,
  'unit': '%'
}, {
  'name': 'Docker',
  'value': 48,
  'unit': '%'
}]

var tab20_5contenttp = [{
  'name': 'Docker',
  'value': 1
}, {
  'name': 'Kuber/netes',
  'value': 1
}]

var tab20_6content = [{
  'name': 'Shippable',
  'value': '<1',
  'unit': '%'
}, {
  'name': 'Codeship',
  'value': 3,
  'unit': '%'
}, {
  'name': 'Circle',
  'value': 8,
  'unit': '%'
}, {
  'name': 'Travis',
  'value': 20,
  'unit': '%'
}, {
  'name': 'Jenkins',
  'value': 23,
  'unit': '%'
}]

var tab20_6contenttp = [{
  'name': 'Travis',
  'value': 0
}, {
  'name': 'Codeship',
  'value': 0
}]

var tab20_7content = [{
  'name': 'NSQ',
  'value': '<1',
  'unit': '%'
}, {
  'name': 'ActiveMQ',
  'value': 1,
  'unit': '%'
}, {
  'name': 'ZeroMQ',
  'value': 3,
  'unit': '%'
}, {
  'name': 'RabbitMQ',
  'value': 13,
  'unit': '%'
}]

var tab20_7contenttp = [{
  'name': 'ZeroMQ',
  'value': 0
}]

var tab23_1_1content = [{
  'name': 'Arch Linux',
  'value': 3,
  'unit': '%'
}, {
  'name': 'Ent. Linux & Fedora',
  'value': 16,
  'unit': '%'
}, {
  'name': 'Debian-based Linux',
  'value': 14,
  'unit': '%'
}, {
  'name': 'Ubuntu',
  'value': 37,
  'unit': '%'
}, {
  'name': 'Windows',
  'value': 12,
  'unit': '%'
}, {
  'name': 'MAC OS',
  'value': 6,
  'unit': '%'
}]

var tab23_1_1contenttp = [{
  'name': 'Windows',
  'value': 1
}]

var tab23_1_2content = [{
  'name': 'Arch Linux',
  'value': 3,
  'unit': '%'
}, {
  'name': 'Ent. Linux & Fedora',
  'value': 11,
  'unit': '%'
}, {
  'name': 'Debian-based Linux',
  'value': 26,
  'unit': '%'
}, {
  'name': 'Ubuntu',
  'value': 37,
  'unit': '%'
}, {
  'name': 'Windows',
  'value': 12,
  'unit': '%'
}, {
  'name': 'MAC OS',
  'value': 3,
  'unit': '%'
}]

var tab23_1_2contenttp = [{
  'name': 'Windows',
  'value': 1
}]

var tab23_1_3content = [{
  'name': 'Arch Linux',
  'value': 2,
  'unit': '%'
}, {
  'name': 'Ent. Linux & Fedora',
  'value': 15,
  'unit': '%'
}, {
  'name': 'Debian-based Linux',
  'value': 16,
  'unit': '%'
}, {
  'name': 'Ubuntu',
  'value': 45,
  'unit': '%'
}, {
  'name': 'Windows',
  'value': 14,
  'unit': '%'
}, {
  'name': 'MAC OS',
  'value': 3,
  'unit': '%'
}]

var tab23_1_4content = [{
  'name': 'Arch Linux',
  'value': 1,
  'unit': '%'
}, {
  'name': 'Ent. Linux & Fedora',
  'value': 17,
  'unit': '%'
}, {
  'name': 'Debian-based Linux',
  'value': 28,
  'unit': '%'
}, {
  'name': 'Ubuntu',
  'value': 41,
  'unit': '%'
}, {
  'name': 'Windows',
  'value': 3,
  'unit': '%'
}, {
  'name': 'MAC OS',
  'value': 3,
  'unit': '%'
}]

var tab23_2_1content = [{
  'name': 'Arch Linux',
  'value': 2,
  'unit': '%'
}, {
  'name': 'Ent. Linux & Fedora',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Debian-based Linux',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Ubuntu',
  'value': 15,
  'unit': '%'
}, {
  'name': 'Windows',
  'value': 22,
  'unit': '%'
}, {
  'name': 'MAC OS',
  'value': 50,
  'unit': '%'
}]

var tab23_2_1contenttp = [{
  'name': 'Windows',
  'value': 1
}, {
  'name': 'MAC OS',
  'value': 0
}]

var tab23_2_2content = [{
  'name': 'Arch Linux',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Ent. Linux & Fedora',
  'value': 3,
  'unit': '%'
}, {
  'name': 'Debian-based Linux',
  'value': 6,
  'unit': '%'
}, {
  'name': 'Ubuntu',
  'value': 21,
  'unit': '%'
}, {
  'name': 'Windows',
  'value': 27,
  'unit': '%'
}, {
  'name': 'MAC OS',
  'value': 35,
  'unit': '%'
}]

var tab23_2_2contenttp = [{
  'name': 'Windows',
  'value': 1
}, {
  'name': 'MAC OS',
  'value': 0
}]

var tab23_2_3content = [{
  'name': 'Arch Linux',
  'value': 3,
  'unit': '%'
}, {
  'name': 'Ent. Linux & Fedora',
  'value': 3,
  'unit': '%'
}, {
  'name': 'Debian-based Linux',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Ubuntu',
  'value': 27,
  'unit': '%'
}, {
  'name': 'Windows',
  'value': 23,
  'unit': '%'
}, {
  'name': 'MAC OS',
  'value': 40,
  'unit': '%'
}]

var tab23_2_4content = [{
  'name': 'Arch Linux',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Ent. Linux & Fedora',
  'value': 3,
  'unit': '%'
}, {
  'name': 'Debian-based Linux',
  'value': 5,
  'unit': '%'
}, {
  'name': 'Ubuntu',
  'value': 37,
  'unit': '%'
}, {
  'name': 'Windows',
  'value': 15,
  'unit': '%'
}, {
  'name': 'MAC OS',
  'value': 33,
  'unit': '%'
}]

var tab24_1_1content = [{
  'name': 'Arch Linux',
  'value': 3,
  'unit': '%'
}, {
  'name': 'Ent. Linux & Fedora',
  'value': 17,
  'unit': '%'
}, {
  'name': 'Debian-based Linux',
  'value': 19,
  'unit': '%'
}, {
  'name': 'Ubuntu',
  'value': 42,
  'unit': '%'
}, {
  'name': 'Windows',
  'value': 8,
  'unit': '%'
}, {
  'name': 'MAC OS',
  'value': 3,
  'unit': '%'
}]

var tab24_1_1contenttp = [{
  'name': 'Arch Linux',
  'value': 1
}]

var tab24_1_2content = [{
  'name': 'Arch Linux',
  'value': 2,
  'unit': '%'
}, {
  'name': 'Ent. Linux & Fedora',
  'value': 12,
  'unit': '%'
}, {
  'name': 'Debian-based Linux',
  'value': 24,
  'unit': '%'
}, {
  'name': 'Ubuntu',
  'value': 41,
  'unit': '%'
}, {
  'name': 'Windows',
  'value': 9,
  'unit': '%'
}, {
  'name': 'MAC OS',
  'value': 3,
  'unit': '%'
}]

var tab24_1_3content = [{
  'name': 'Arch Linux',
  'value': 3,
  'unit': '%'
}, {
  'name': 'Ent. Linux & Fedora',
  'value': 14,
  'unit': '%'
}, {
  'name': 'Debian-based Linux',
  'value': 19,
  'unit': '%'
}, {
  'name': 'Ubuntu',
  'value': 30,
  'unit': '%'
}, {
  'name': 'Windows',
  'value': 18,
  'unit': '%'
}, {
  'name': 'MAC OS',
  'value': 8,
  'unit': '%'
}]

var tab24_1_4content = [{
  'name': 'Arch Linux',
  'value': 2,
  'unit': '%'
}, {
  'name': 'Ent. Linux & Fedora',
  'value': 9,
  'unit': '%'
}, {
  'name': 'Debian-based Linux',
  'value': 15,
  'unit': '%'
}, {
  'name': 'Ubuntu',
  'value': 25,
  'unit': '%'
}, {
  'name': 'Windows',
  'value': 29,
  'unit': '%'
}, {
  'name': 'MAC OS',
  'value': 6,
  'unit': '%'
}]

var tab24_1_4contenttp = [{
  'name': 'Windows',
  'value': 1
}]

var tab24_2_1content = [{
  'name': 'Arch Linux',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Ent. Linux & Fedora',
  'value': 6,
  'unit': '%'
}, {
  'name': 'Debian-based Linux',
  'value': 5,
  'unit': '%'
}, {
  'name': 'Ubuntu',
  'value': 26,
  'unit': '%'
}, {
  'name': 'Windows',
  'value': 21,
  'unit': '%'
}, {
  'name': 'MAC OS',
  'value': 36,
  'unit': '%'
}]

var tab24_2_1contenttp = [{
  'name': 'Windows',
  'value': 1
}, {
  'name': 'MAC OS',
  'value': 0
}]

var tab24_2_2content = [{
  'name': 'Arch Linux',
  'value': 2,
  'unit': '%'
}, {
  'name': 'Ent. Linux & Fedora',
  'value': 3,
  'unit': '%'
}, {
  'name': 'Debian-based Linux',
  'value': 5,
  'unit': '%'
}, {
  'name': 'Ubuntu',
  'value': 20,
  'unit': '%'
}, {
  'name': 'Windows',
  'value': 21,
  'unit': '%'
}, {
  'name': 'MAC OS',
  'value': 47,
  'unit': '%'
}]

var tab24_2_3content = [{
  'name': 'Arch Linux',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Ent. Linux & Fedora',
  'value': 1,
  'unit': '%'
}, {
  'name': 'Debian-based Linux',
  'value': 2,
  'unit': '%'
}, {
  'name': 'Ubuntu',
  'value': 14,
  'unit': '%'
}, {
  'name': 'Windows',
  'value': 29,
  'unit': '%'
}, {
  'name': 'MAC OS',
  'value': 48,
  'unit': '%'
}]

var tab24_2_4content = [{
  'name': 'Arch Linux',
  'value': 3,
  'unit': '%'
}, {
  'name': 'Ent. Linux & Fedora',
  'value': 0,
  'unit': '%'
}, {
  'name': 'Debian-based Linux',
  'value': 6,
  'unit': '%'
}, {
  'name': 'Ubuntu',
  'value': 20,
  'unit': '%'
}, {
  'name': 'Windows',
  'value': 39,
  'unit': '%'
}, {
  'name': 'MAC OS',
  'value': 26,
  'unit': '%'
}]

var tab24_2_4contenttp = [{
  'name': 'Windows',
  'value': 1
}, {
  'name': 'MAC OS',
  'value': 0
}]

var tab27_1_1content = [{
  'name': 'Average #',
  'value': 3.3,
  'unit': '%'
}, {
  'name': 'Ruby',
  'value': 20,
  'unit': '%'
}, {
  'name': 'C',
  'value': 16,
  'unit': '%'
}, {
  'name': 'Go',
  'value': 18,
  'unit': '%'
}, {
  'name': 'C++',
  'value': 20,
  'unit': '%'
}, {
  'name': '.Net',
  'value': 22,
  'unit': '%'
}, {
  'name': 'PHP',
  'value': 23,
  'unit': '%'
}, {
  'name': 'Java',
  'value': 34,
  'unit': '%'
}, {
  'name': 'Python',
  'value': 39,
  'unit': '%'
}, {
  'name': 'JavaScript',
  'value': 93,
  'unit': '%'
}]

var tab27_1_2content = [{
  'name': 'Average #',
  'value': 3.2,
  'unit': '%'
}, {
  'name': 'Ruby',
  'value': 12,
  'unit': '%'
}, {
  'name': 'C',
  'value': 13,
  'unit': '%'
}, {
  'name': 'Go',
  'value': 14,
  'unit': '%'
}, {
  'name': 'C++',
  'value': 16,
  'unit': '%'
}, {
  'name': '.Net',
  'value': 20,
  'unit': '%'
}, {
  'name': 'PHP',
  'value': 37,
  'unit': '%'
}, {
  'name': 'Java',
  'value': 36,
  'unit': '%'
}, {
  'name': 'Python',
  'value': 35,
  'unit': '%'
}, {
  'name': 'JavaScript',
  'value': 93,
  'unit': '%'
}]

var tab27_1_2contenttp = [{
  'name': 'Ruby',
  'value': 0
}, {
  'name': 'C++',
  'value': 0
}]

var tab27_1_3content = [{
  'name': 'Average #',
  'value': 2.8,
  'unit': '%'
}, {
  'name': 'Ruby',
  'value': 8,
  'unit': '%'
}, {
  'name': 'C',
  'value': 15,
  'unit': '%'
}, {
  'name': 'Go',
  'value': 15,
  'unit': '%'
}, {
  'name': 'C++',
  'value': 13,
  'unit': '%'
}, {
  'name': '.Net',
  'value': 19,
  'unit': '%'
}, {
  'name': 'PHP',
  'value': 29,
  'unit': '%'
}, {
  'name': 'Java',
  'value': 30,
  'unit': '%'
}, {
  'name': 'Python',
  'value': 35,
  'unit': '%'
}, {
  'name': 'JavaScript',
  'value': 89,
  'unit': '%'
}]

var tab27_1_3contenttp = [{
  'name': '.Net',
  'value': 1
}]

var tab27_1_4content = [{
  'name': 'Average #',
  'value': 3.3,
  'unit': '%'
}, {
  'name': 'Ruby',
  'value': 11,
  'unit': '%'
}, {
  'name': 'C',
  'value': 15,
  'unit': '%'
}, {
  'name': 'Go',
  'value': 20,
  'unit': '%'
}, {
  'name': 'C++',
  'value': 8,
  'unit': '%'
}, {
  'name': '.Net',
  'value': 19,
  'unit': '%'
}, {
  'name': 'PHP',
  'value': 38,
  'unit': '%'
}, {
  'name': 'Java',
  'value': 48,
  'unit': '%'
}, {
  'name': 'Python',
  'value': 39,
  'unit': '%'
}, {
  'name': 'JavaScript',
  'value': 96,
  'unit': '%'
}]

var tab27_1_4contenttp = [{
  'name': 'C++',
  'value': 0
}]

var tab27_2_1content = [{
  'name': 'Average #',
  'value': 3.2,
  'unit': '%'
}, {
  'name': 'Ruby',
  'value': 12,
  'unit': '%'
}, {
  'name': 'C',
  'value': 15,
  'unit': '%'
}, {
  'name': 'Go',
  'value': 17,
  'unit': '%'
}, {
  'name': 'C++',
  'value': 15,
  'unit': '%'
}, {
  'name': '.Net',
  'value': 21,
  'unit': '%'
}, {
  'name': 'PHP',
  'value': 31,
  'unit': '%'
}, {
  'name': 'Java',
  'value': 36,
  'unit': '%'
}, {
  'name': 'Python',
  'value': 36,
  'unit': '%'
}, {
  'name': 'JavaScript',
  'value': 92,
  'unit': '%'
}]

var tab27_2_1contenttp = [{
  'name': 'C++',
  'value': 0
}, {
  'name': 'Ruby',
  'value': 0
}]

var tab27_2_2content = [{
  'name': 'Average #',
  'value': 3.2,
  'unit': '%'
}, {
  'name': 'Ruby',
  'value': 14,
  'unit': '%'
}, {
  'name': 'C',
  'value': 13,
  'unit': '%'
}, {
  'name': 'Go',
  'value': 17,
  'unit': '%'
}, {
  'name': 'C++',
  'value': 15,
  'unit': '%'
}, {
  'name': '.Net',
  'value': 19,
  'unit': '%'
}, {
  'name': 'PHP',
  'value': 35,
  'unit': '%'
}, {
  'name': 'Java',
  'value': 34,
  'unit': '%'
}, {
  'name': 'Python',
  'value': 38,
  'unit': '%'
}, {
  'name': 'JavaScript',
  'value': 95,
  'unit': '%'
}]

var tab27_2_2contenttp = [{
  'name': 'C',
  'value': 0
}, {
  'name': 'C++',
  'value': 0
}]

var tab27_2_3content = [{
  'name': 'Average #',
  'value': 2.9,
  'unit': '%'
}, {
  'name': 'Ruby',
  'value': 14,
  'unit': '%'
}, {
  'name': 'C',
  'value': 10,
  'unit': '%'
}, {
  'name': 'Go',
  'value': 11,
  'unit': '%'
}, {
  'name': 'C++',
  'value': 13,
  'unit': '%'
}, {
  'name': '.Net',
  'value': 21,
  'unit': '%'
}, {
  'name': 'PHP',
  'value': 29,
  'unit': '%'
}, {
  'name': 'Java',
  'value': 35,
  'unit': '%'
}, {
  'name': 'Python',
  'value': 33,
  'unit': '%'
}, {
  'name': 'JavaScript',
  'value': 94,
  'unit': '%'
}]

var tab27_2_3contenttp = [{
  'name': 'C',
  'value': 1
}]

var tab27_2_4content = [{
  'name': 'Average #',
  'value': 3.6,
  'unit': '%'
}, {
  'name': 'Ruby',
  'value': 16,
  'unit': '%'
}, {
  'name': 'C',
  'value': 28,
  'unit': '%'
}, {
  'name': 'Go',
  'value': 15,
  'unit': '%'
}, {
  'name': 'C++',
  'value': 33,
  'unit': '%'
}, {
  'name': '.Net',
  'value': 26,
  'unit': '%'
}, {
  'name': 'PHP',
  'value': 21,
  'unit': '%'
}, {
  'name': 'Java',
  'value': 39,
  'unit': '%'
}, {
  'name': 'Python',
  'value': 41,
  'unit': '%'
}, {
  'name': 'JavaScript',
  'value': 84,
  'unit': '%'
}]

var tab27_2_4contenttp = [{
  'name': 'Java',
  'value': 1
}]

var tab45_1content = [{
  'name': 'Conferences',
  'value': 11,
  'unit': '%'
}, {
  'name': 'Meetup talk events',
  'value': 10,
  'unit': '%'
}, {
  'name': 'Technical podcasts',
  'value': 16,
  'unit': '%'
}, {
  'name': 'Conference talk videos',
  'value': 19,
  'unit': '%'
}, {
  'name': 'Paid online courses',
  'value': 35,
  'unit': '%'
}, {
  'name': 'Publications',
  'value': 39,
  'unit': '%'
}, {
  'name': 'Tutorial videos',
  'value': 62,
  'unit': '%'
}, {
  'name': 'Free online courses',
  'value': 66,
  'unit': '%'
}, {
  'name': 'Stack Overflow',
  'value': 71,
  'unit': '%'
}, {
  'name': 'Documentation',
  'value': 80,
  'unit': '%'
}]

var tab45_2content = [{
  'name': 'Conferences',
  'value': 18,
  'unit': '%'
}, {
  'name': 'Meetup talk events',
  'value': 17,
  'unit': '%'
}, {
  'name': 'Technical podcasts',
  'value': 19,
  'unit': '%'
}, {
  'name': 'Conference talk videos',
  'value': 29,
  'unit': '%'
}, {
  'name': 'Paid online courses',
  'value': 24,
  'unit': '%'
}, {
  'name': 'Publications',
  'value': 40,
  'unit': '%'
}, {
  'name': 'Tutorial videos',
  'value': 52,
  'unit': '%'
}, {
  'name': 'Free online courses',
  'value': 52,
  'unit': '%'
}, {
  'name': 'StackOverflow',
  'value': 72,
  'unit': '%'
}, {
  'name': 'Documentation',
  'value': 88,
  'unit': '%'
}]

var tab46_1content = [{
  'name': 'Technical podcasts',
  'value': 12,
  'unit': '%'
}, {
  'name': 'Paid online courses',
  'value': 14,
  'unit': '%'
}, {
  'name': 'Meetup talk events',
  'value': 14,
  'unit': '%'
}, {
  'name': 'Conferences',
  'value': 12,
  'unit': '%'
}, {
  'name': 'Case studies   ',
  'value': 15,
  'unit': '%'
}, {
  'name': 'Tutorial videos',
  'value': 30,
  'unit': '%'
}, {
  'name': 'Free online courses',
  'value': 42,
  'unit': '%'
}, {
  'name': 'Documentation',
  'value': 33,
  'unit': '%'
}]

var tab46_2content = [{
  'name': 'Technical podcasts',
  'value': 12,
  'unit': '%'
}, {
  'name': 'Paid online courses',
  'value': 10,
  'unit': '%'
}, {
  'name': 'Meetup talk events',
  'value': 12,
  'unit': '%'
}, {
  'name': 'Conferences',
  'value': 16,
  'unit': '%'
}, {
  'name': 'Case studies   ',
  'value': 16,
  'unit': '%'
}, {
  'name': 'Tutorial videos',
  'value': 25,
  'unit': '%'
}, {
  'name': 'Free online courses',
  'value': 27,
  'unit': '%'
}, {
  'name': 'Documentation',
  'value': 34,
  'unit': '%'
}]

var tab47_1_1content = [{
  'name': 'Conference talk videos',
  'value': 12,
  'unit': '%'
}, {
  'name': 'Technical podcasts',
  'value': 15,
  'unit': '%'
}, {
  'name': 'Meet-up talk events',
  'value': 11,
  'unit': '%'
}, {
  'name': 'Meet-up coding events',
  'value': 13,
  'unit': '%'
}, {
  'name': 'Case studies',
  'value': 11,
  'unit': '%'
}, {
  'name': 'Conferences',
  'value': 14,
  'unit': '%'
}, {
  'name': 'Tutorial videos',
  'value': 27,
  'unit': '%'
}, {
  'name': 'Free online courses',
  'value': 32,
  'unit': '%'
}, {
  'name': 'Documentation',
  'value': 34,
  'unit': '%'
}]

var tab47_1_2content = [{
  'name': 'Conference talk videos',
  'value': 10,
  'unit': '%'
}, {
  'name': 'Technical podcasts',
  'value': 10,
  'unit': '%'
}, {
  'name': 'Meet-up talk events',
  'value': 9,
  'unit': '%'
}, {
  'name': 'Meet-up coding events',
  'value': 10,
  'unit': '%'
}, {
  'name': 'Case studies',
  'value': 16,
  'unit': '%'
}, {
  'name': 'Conferences',
  'value': 12,
  'unit': '%'
}, {
  'name': 'Tutorial videos',
  'value': 24,
  'unit': '%'
}, {
  'name': 'Free online courses',
  'value': 31,
  'unit': '%'
}, {
  'name': 'Documentation',
  'value': 34,
  'unit': '%'
}]

var tab47_1_3content = [{
  'name': 'Conference talk videos',
  'value': 11,
  'unit': '%'
}, {
  'name': 'Technical podcasts',
  'value': 12,
  'unit': '%'
}, {
  'name': 'Meet-up talk events',
  'value': 14,
  'unit': '%'
}, {
  'name': 'Meet-up coding events',
  'value': 17,
  'unit': '%'
}, {
  'name': 'Case studies',
  'value': 22,
  'unit': '%'
}, {
  'name': 'Conferences',
  'value': 15,
  'unit': '%'
}, {
  'name': 'Tutorial videos',
  'value': 30,
  'unit': '%'
}, {
  'name': 'Free online courses',
  'value': 36,
  'unit': '%'
}, {
  'name': 'Documentation',
  'value': 34,
  'unit': '%'
}]

var tab47_1_4content = [{
  'name': 'Conference talk videos',
  'value': 22,
  'unit': '%'
}, {
  'name': 'Technical podcasts',
  'value': 17,
  'unit': '%'
}, {
  'name': 'Meet-up talk events',
  'value': 17,
  'unit': '%'
}, {
  'name': 'Meet-up coding events',
  'value': 17,
  'unit': '%'
}, {
  'name': 'Case studies',
  'value': 21,
  'unit': '%'
}, {
  'name': 'Conferences',
  'value': 29,
  'unit': '%'
}, {
  'name': 'Tutorial videos',
  'value': 39,
  'unit': '%'
}, {
  'name': 'Free online courses',
  'value': 46,
  'unit': '%'
}, {
  'name': 'Documentation',
  'value': 36,
  'unit': '%'
}]

var tab47_1_4contenttp = [{
  'name': 'Conference talk videos',
  'value': 1
}]

var tab47_2_1content = [{
  'name': 'Conference talk videos',
  'value': 14,
  'unit': '%'
}, {
  'name': 'Technical podcasts',
  'value': 18,
  'unit': '%'
}, {
  'name': 'Meet-up talk events',
  'value': 13,
  'unit': '%'
}, {
  'name': 'Meet-up coding events',
  'value': 16,
  'unit': '%'
}, {
  'name': 'Case studies',
  'value': 19,
  'unit': '%'
}, {
  'name': 'Conferences',
  'value': 18,
  'unit': '%'
}, {
  'name': 'Tutorial videos',
  'value': 31,
  'unit': '%'
}, {
  'name': 'Free online courses',
  'value': 39,
  'unit': '%'
}, {
  'name': 'Documentation',
  'value': 40,
  'unit': '%'
}]

var tab47_2_2content = [{
  'name': 'Conference talk videos',
  'value': 13,
  'unit': '%'
}, {
  'name': 'Technical podcasts',
  'value': 14,
  'unit': '%'
}, {
  'name': 'Meet-up talk events',
  'value': 14,
  'unit': '%'
}, {
  'name': 'Meet-up coding events',
  'value': 15,
  'unit': '%'
}, {
  'name': 'Case studies',
  'value': 17,
  'unit': '%'
}, {
  'name': 'Conferences',
  'value': 18,
  'unit': '%'
}, {
  'name': 'Tutorial videos',
  'value': 35,
  'unit': '%'
}, {
  'name': 'Free online courses',
  'value': 38,
  'unit': '%'
}, {
  'name': 'Documentation',
  'value': 38,
  'unit': '%'
}]

var tab47_2_3content = [{
  'name': 'Conference talk videos',
  'value': 11,
  'unit': '%'
}, {
  'name': 'Technical podcasts',
  'value': 10,
  'unit': '%'
}, {
  'name': 'Meet-up talk events',
  'value': 8,
  'unit': '%'
}, {
  'name': 'Meet-up coding events',
  'value': 9,
  'unit': '%'
}, {
  'name': 'Case studies',
  'value': 16,
  'unit': '%'
}, {
  'name': 'Conferences',
  'value': 12,
  'unit': '%'
}, {
  'name': 'Tutorial videos',
  'value': 27,
  'unit': '%'
}, {
  'name': 'Free online courses',
  'value': 38,
  'unit': '%'
}, {
  'name': 'Documentation',
  'value': 35,
  'unit': '%'
}]

var tab47_2_3contenttp = [{
  'name': 'Meet-up talk events',
  'value': 0
}, {
  'name': 'Meet-up coding events',
  'value': 0
}, {
  'name': 'Conferences',
  'value': 0
}]

var tab47_2_4content = [{
  'name': 'Conference talk videos',
  'value': 12,
  'unit': '%'
}, {
  'name': 'Technical podcasts',
  'value': 7,
  'unit': '%'
}, {
  'name': 'Meet-up talk events',
  'value': 10,
  'unit': '%'
}, {
  'name': 'Meet-up coding events',
  'value': 13,
  'unit': '%'
}, {
  'name': 'Case studies',
  'value': 15,
  'unit': '%'
}, {
  'name': 'Conferences',
  'value': 10,
  'unit': '%'
}, {
  'name': 'Tutorial videos',
  'value': 23,
  'unit': '%'
}, {
  'name': 'Free online courses',
  'value': 35,
  'unit': '%'
}, {
  'name': 'Documentation',
  'value': 34,
  'unit': '%'
}]

var tab47_2_4contenttp = [{
  'name': 'Conferences',
  'value': 0
}, {
  'name': 'Documentation',
  'value': 0
}]

var tab56_1content = [{
  'name': 'No impact',
  'value': 9,
  'unit': '%'
}, {
  'name': 'Helped recruit developers',
  'value': 15,
  'unit': '%'
}, {
  'name': 'Increased uptime',
  'value': 19,
  'unit': '%'
}, {
  'name': 'Increased application performance',
  'value': 42,
  'unit': '%'
}, {
  'name': 'Reduced development costs',
  'value': 45,
  'unit': '%'
}, {
  'name': 'Improved developer satisfaction',
  'value': 51,
  'unit': '%'
}, {
  'name': 'Increased developer productivity',
  'value': 58,
  'unit': '%'
}]

var tab56_2content = [{
  'name': 'No impact',
  'value': 4,
  'unit': '%'
}, {
  'name': 'Helped recruit developers',
  'value': 27,
  'unit': '%'
}, {
  'name': 'Increased uptime',
  'value': 27,
  'unit': '%'
}, {
  'name': 'Increased application performance',
  'value': 51,
  'unit': '%'
}, {
  'name': 'Reduced development costs',
  'value': 62,
  'unit': '%'
}, {
  'name': 'Improved developer satisfaction',
  'value': 68,
  'unit': '%'
}, {
  'name': 'Increased developer productivity',
  'value': 74,
  'unit': '%'
}]

var tab57_1content = [{
  'name': 'No impact',
  'value': 7,
  'unit': '%'
}, {
  'name': 'Helped recruit developers',
  'value': 34,
  'unit': '%'
}, {
  'name': 'Increased uptime',
  'value': 22,
  'unit': '%'
}, {
  'name': 'Increased application performance',
  'value': 43,
  'unit': '%'
}, {
  'name': 'Reduced development costs',
  'value': 60,
  'unit': '%'
}, {
  'name': 'Improved developer satisfaction',
  'value': 64,
  'unit': '%'
}, {
  'name': 'Increased developer productivity',
  'value': 68,
  'unit': '%'
}]

var tab57_2content = [{
  'name': 'No impact',
  'value': 6,
  'unit': '%'
}, {
  'name': 'Helped recruit developers',
  'value': 18,
  'unit': '%'
}, {
  'name': 'Increased uptime',
  'value': 23,
  'unit': '%'
}, {
  'name': 'Increased application performance',
  'value': 47,
  'unit': '%'
}, {
  'name': 'Reduced development costs',
  'value': 51,
  'unit': '%'
}, {
  'name': 'Improved developer satisfaction',
  'value': 60,
  'unit': '%'
}, {
  'name': 'Increased developer productivity',
  'value': 66,
  'unit': '%'
}]

var tab57_2contenttp = [{
  'name': 'Increased application performance',
  'value': 47
}, {
  'name': 'Improved developer satisfaction',
  'value': 60
}]

var tab57_3content = [{
  'name': 'No impact',
  'value': 3,
  'unit': '%'
}, {
  'name': 'Helped recruit developers',
  'value': 18,
  'unit': '%'
}, {
  'name': 'Increased uptime',
  'value': 24,
  'unit': '%'
}, {
  'name': 'Increased application performance',
  'value': 53,
  'unit': '%'
}, {
  'name': 'Reduced development costs',
  'value': 61,
  'unit': '%'
}, {
  'name': 'Improved developer satisfaction',
  'value': 60,
  'unit': '%'
}, {
  'name': 'Increased developer productivity',
  'value': 69,
  'unit': '%'
}]

var tab57_4content = [{
  'name': 'No impact',
  'value': 3,
  'unit': '%'
}, {
  'name': 'Helped recruit developers',
  'value': 12,
  'unit': '%'
}, {
  'name': 'Increased uptime',
  'value': 40,
  'unit': '%'
}, {
  'name': 'Increased application performance',
  'value': 63,
  'unit': '%'
}, {
  'name': 'Reduced development costs',
  'value': 56,
  'unit': '%'
}, {
  'name': 'Improved developer satisfaction',
  'value': 65,
  'unit': '%'
}, {
  'name': 'Increased developer productivity',
  'value': 78,
  'unit': '%'
}]

var tab57_4contenttp = [{
  'name': 'Increased developer productivity',
  'value': 1
}]
