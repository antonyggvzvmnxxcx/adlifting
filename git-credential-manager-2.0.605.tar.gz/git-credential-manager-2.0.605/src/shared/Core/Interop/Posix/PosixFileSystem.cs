
namespace GitCredentialManager.Interop.Posix
{
    public abstract class PosixFileSystem : FileSystem
    {
    }
}