using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Core.Tests")]

