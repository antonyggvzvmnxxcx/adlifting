using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("Microsoft.AzureRepos.Tests")]
