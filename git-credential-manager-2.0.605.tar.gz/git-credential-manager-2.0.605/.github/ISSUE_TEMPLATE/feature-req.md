---
name: Feature request
about: A suggestion for a new feature in Git Credential Manager Core.
title: ''
labels: 'enhancement'
assignees: ''
---

**Feature description**

A clear and concise description of the new feature.
