#!/bin/sh

./user-sync --process-groups --users mapped -t
