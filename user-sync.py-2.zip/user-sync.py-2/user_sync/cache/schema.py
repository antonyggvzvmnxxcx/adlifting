cache_meta = """
create table if not exists cache_meta (
    next_refresh timestamp,
    version integer
);
"""
