---
name: General question
about: Issues that are neither bugs nor feature requests
title: ''
labels: ''
assignees: ''

---

<!-- Ask any question you want about the User Sync Tool. Please provide configuration files when applicable. You can post them by dragging
and dropping the file to this input box. Be sure to remove any sensitive information such as credentials, hosts, account names or email
addresses !-->
