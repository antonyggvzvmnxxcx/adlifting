# User Sync de Adobe #

La documentación de User Sync de Adobe se puede encontrar en línea:

[https://adobe-apiplatform.github.io/user-sync.py/](https://adobe-apiplatform.github.io/user-sync.py/)

La versión más reciente siempre puede encontrarse en:

[https://github.com/adobe-apiplatform/user-sync.py/releases/latest](https://github.com/adobe-apiplatform/user-sync.py/releases/latest)
