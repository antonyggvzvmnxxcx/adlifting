# Benutzersynchronisation von Adobe #

Die Dokumentation für das Benutzer-Synchronisationstool von Adobe finden Sie online:

[https://adobe-apiplatform.github.io/user-sync.py/](https://adobe-apiplatform.github.io/user-sync.py/)

Die neueste Version findet sich stets auf folgender Seite:

[https://github.com/adobe-apiplatform/user-sync.py/releases/latest](https://github.com/adobe-apiplatform/user-sync.py/releases/latest)
