# Adobe の User Sync #

Adobe の User Sync のドキュメントはオンラインで見つけることができます。

[https://adobe-apiplatform.github.io/user-sync.py/](https://adobe-apiplatform.github.io/user-sync.py/)

最新リリースは常に次の場所にあります。

[https://github.com/adobe-apiplatform/user-sync.py/releases/latest](https://github.com/adobe-apiplatform/user-sync.py/releases/latest)
